
<?php

require_once("inc/functions.php");

?>

<!DOCTYPE html>

<html>

<head>

<?php load_headers(); ?>


</head>

<body>

	<center>
	
	<div id="main">
	<span>
		<center>
		<img src='inc/images/uw_mobile_banner.jpg' style="max-height:60vh;width:80%;max-width:400px;">
		</center>
	</span>
	</div>

	<?php main_menu(); ?>
	
	</center>

</body>

</html>