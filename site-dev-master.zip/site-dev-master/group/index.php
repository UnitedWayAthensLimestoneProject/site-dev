<?php

	header("Location:welcome.html");
	exit();

?>